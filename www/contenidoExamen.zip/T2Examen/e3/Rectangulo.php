<?php

namespace e3;

class Rectangulo
{

}
