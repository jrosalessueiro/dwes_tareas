<?php

// Destruir la sesión correctamente

// Redirigir al formulario de inicio de sesión
header('Location: index.php');
exit();
